package Enum;

public enum Chuc_vu {
	TRƯỞNG_PHÒNG, PHÓ_PHÒNG, NHÂN_VIÊN;
}

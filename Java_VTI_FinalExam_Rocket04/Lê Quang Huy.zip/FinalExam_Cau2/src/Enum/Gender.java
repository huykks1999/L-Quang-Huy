package Enum;

public enum Gender {
	NAM("Nam"), NỮ("Nữ"), KHÁC("Khác");
	String value;
	private Gender(String value) {
		this.value = value;
	}
}

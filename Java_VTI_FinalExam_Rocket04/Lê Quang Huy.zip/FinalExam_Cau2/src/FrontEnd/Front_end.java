package FrontEnd;

import java.util.Date;

import BackEnd.Service;
import Entity.Nam;
import Entity.Nhan_Vien;
import Entity.Nu;
import Enum.Chuc_vu;

public class Front_end {

	public static void main(String[] args) {
		Nhan_Vien nv1 = new Nam("1", "Le quang huy","Huykks","huylequangkks@gmail.com",
				new Date(2015-1900, 8-1, 17),"0966621846",Chuc_vu.TRƯỞNG_PHÒNG, true, true);
		
		Nhan_Vien nv2 = new Nu("1", "Le thi lieu","Huykks","huylequangkks@gmail.com",
				new Date(2009-1900, 5-1, 17),"0966621846",Chuc_vu.TRƯỞNG_PHÒNG, false, true);
		Service.inDanhSach();

	}

}

package BackEnd;

import Entity.Nhan_Vien;

public class Service {
	public static void inDanhSach() {
		for (Nhan_Vien nv : Nhan_Vien.Nhan_vien) {
			System.out.println("ID: "+nv.getEmployeeID());
			System.out.println("FullName: "+nv.getFullName());
			System.out.println("Email: "+nv.getEmail());
			System.out.println("Thâm niên: "+nv.getTham_nien());
			System.out.println("Số ngày nghỉ: "+nv.getSo_ngay_nghỉ() );
			System.out.println("----------------------------------------------");
			System.out.println("----------------------------------------------");
		
		}
	}
}

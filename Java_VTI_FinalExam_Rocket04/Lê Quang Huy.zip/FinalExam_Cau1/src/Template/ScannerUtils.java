package Template;
import java.util.Scanner;

public class ScannerUtils {
	public static int inputInt() {
		Scanner sc = new Scanner(System.in);
		boolean check = false;
		do {
			try {
				String s = sc.nextLine();
		        int i = Integer.parseInt(s);
		        return i;
		     
			} catch (Exception e) {
				System.out.println("Bạn đã nhập sai, xin mời bạn nhập vào một số!!!");
				check = true;
			}
			
		} while (check);
		return 0;
		
	}
	
	
	public static int inputInt(String error) {
		Scanner sc = new Scanner(System.in);
		boolean check;
		do {
			check = false;
			try {
				String s = sc.nextLine();
		        int i = Integer.parseInt(s);
		        return i;
		     
			} catch (Exception e) {
				System.out.println(error);
				check = true;
			}
			
		} while (check);
		return 0;
		
	}
}

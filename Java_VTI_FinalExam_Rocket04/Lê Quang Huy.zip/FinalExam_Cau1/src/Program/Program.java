package Program;

import java.util.Scanner;

import Template.ScannerUtils;

public class Program {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Mời bạn nhập hệ số của phương trình bậc 2(aX2+bX+c=0)");
		System.out.print("a= ");
		double a = ScannerUtils.inputInt();
		System.out.print("b= ");
		double b = ScannerUtils.inputInt();
		System.out.print("c= ");
		double c = ScannerUtils.inputInt();
		double delta = b*b - 4*a*c;
		if(delta>0) {
			double nghiem1 = (-b+Math.sqrt(delta))/(2*a);
			double nghiem2 = (-b-Math.sqrt(delta))/(2*a);
			System.out.println("Phương trình có 2 nghiệm là: ");
			System.out.println("Nghiệm 1: "+nghiem1 );
			System.out.println("Nghiệm 2: "+nghiem2);
		}else if(delta==0) {
			double nghiem = -b/(2*a);
			System.out.println("Phương trình có 1 nghiệm duy nhất là: "+nghiem);
		}else {
			System.out.println("Phương trình này vô nghiệm");
		}

	}

}
